# Host Trust Wrapper v1 最小整改设计

状态：设计提案，未接入生产；不得修改 Runtime Identity v1.2 或 D 合同。

## 目标

把当前 evidence-only `validateGraphReference()` 放在宿主拥有的版本化包装层之后。caller 只能提交观察 envelope；不能提交或覆盖 registry 里的 Graph、sourceMappings、project、side、run/check 或 artifact lineage。

## 建议接口

```ts
type HostTrustResult = {
  hostBinding: 'verified' | 'unavailable' | 'conflict' | 'stale'
  observationStatus: 'complete' | 'partial' | 'unknown' | 'unavailable' | 'stale'
  graphReference: 'verified' | 'rejected' | 'unavailable'
  runtimeProof: 'none' | 'separately-verified'
  trusted: false | 'host-bound-complete'
  reasonCode: ObservationReasonCode
  diagnostics: string[]
}

interface HostTrustRegistryV1 {
  readProject(projectId: string): RegisteredProject | null
  readRunPoint(runId: string, checkId: string, side: Side): TrustedRunPoint | null
  readSideBinding(runId: string, checkId: string, side: Side): RegisteredSideBinding | null
  readVerifiedSideGraph(binding: RegisteredSideBinding): VerifiedSideGraph | null
  readVerifiedSourceSnapshot(binding: RegisteredSideBinding): VerifiedSourceSnapshot | null
  readArtifactLineage(runId: string, checkId: string, side: Side, artifact: Artifact): ArtifactLineageResult
}

function validateHostObservationV1(
  envelope: ObservationBindingV1,
  registry: HostTrustRegistryV1,
): HostTrustResult
```

`HostSideBindingV1`、Graph 和 sourceMappings 由 registry lookup 得到，不能从 envelope 读取。若实现必须调用纯函数 helper，包装层才可把 registry 读取结果传入 helper。

## 必须执行的顺序

1. 由宿主 check plan 选出唯一 `(projectId, runId, checkId, side)`。
2. registry 读取 project、side binding、Graph 和源码快照；缺失、重复、冲突、stale 都返回 `unavailable`/`conflict`。
3. 对源码快照重新计算 `sourceDigest`；对完整 side Graph 和 host-built sourceMappings 重新计算 `graphDigest`。
4. 比对 Graph version、mapping version、projectId、side、sourceDigest、graphDigest；caller claim 只能作为待比对数据。
5. 比对 envelope 的 run/check/side、route、pathname/search/hash、viewport、state 与 trusted check plan。
6. 验证 artifact 路径、字节 SHA、size 和 lineage；历史 artifact 不能挂到新 run/check。
7. 调用纯 Graph reference validator；`sourceMappings` 仍须来自 verified Graph/source snapshot。
8. 只有全部条件满足且 `status === 'complete'`、`primaryReasonCode === 'observation/complete'` 时，才允许内部标记 `host-bound-complete`。
9. `unknown`、`partial`、`unavailable`、`stale` 永远返回 `trusted: false`。
10. 该结果仍只能供只读 evidence / E pairing 使用，不能进入 Scope、Approval、Apply、Rollback 或七项 Verification 授权。

## 语义修复

- 不把裸 `trusted: boolean` 暴露给一般消费者；优先改成 `host-bound-complete` 语义，避免被误读成 runtime proof。
- `runtimeProof` 必须由 Runtime Identity v1.2 宿主 Assessment 单独提供；V2 Graph evidence 不得填充它。
- 静态 `reads` / `source-proven` 只证明 Graph source-use 关系。JSX consumer strict proof 必须另有合法的 consumer edge、运行时捕获和现有 E 规则。
- `graphDigest`、`observationBindingDigest`、`snapshotSha256`、`assessmentSha256`、`runtimeInstanceId` 各自保持原定义，不互相替代。

## 代码白名单（未来获批后）

允许新增或局部修改：

- `src/core/observation-host-trust-v1.ts`：唯一包装层与 registry interface。
- `src/core/observation-host-trust-v1.test.ts`：本矩阵和真实 registry double 的测试。
- `src/core/observation-host-registry-v1.ts`：仅宿主侧注册/读取适配，不接受 caller 写入。
- `docs/acceptance/.../e-h0-*`：证据、黄金向量和回归报告。

明确禁止：

- `src/core/model.ts`、Runtime Identity assessment/pairing、VerificationRun/Assessment 字段修改；
- D collector、C SourceGraph producer、B v5 migration；
- Scope、Candidate、Approval、Apply、Rollback 和七项 Verification 门控；
- 用 observation `trusted` 改写任何授权状态；
- 把 Graph/sourceMappings 写入正式 RI 回执。
