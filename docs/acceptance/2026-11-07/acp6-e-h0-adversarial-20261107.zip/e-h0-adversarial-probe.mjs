import { readFile } from 'node:fs/promises'
import { fileURLToPath } from 'node:url'
import { resolve } from 'node:path'
import { canonicalGraph, validateGraphReference } from './reference/canonical-observation-digest.mjs'
const vectorDir = new URL('./inputs/', import.meta.url)
const read = async n => JSON.parse(await readFile(new URL(n, vectorDir), 'utf8'))
const g0 = await read('g0.json')
const b0 = await read('b0-observation.json')
const graph0 = canonicalGraph(g0)
b0.graph.graphDigest = graph0.digest
const host = { side:'baseline', projectId:g0.projectId, graphIdentityVersion:g0.graphIdentityVersion, graphSchemaVersion:g0.graphSchemaVersion, relationIdentityVersion:g0.relationIdentityVersion, sourceMappingVersion:g0.sourceMappingVersion, sourceDigest:g0.sourceDigest, graphDigest:graph0.digest }
const observe = (name, expected, classification, inputSummary, fn) => {
  try {
    const result = fn()
    return { name, expected, classification, inputSummary, actual: { accepted:true, result }, pass: expected === 'accept' || expected === 'accept-static-only' }
  } catch (e) {
    return { name, expected, classification, inputSummary, actual: { accepted:false, code:e.code ?? 'uncoded', message:e.message }, pass: expected !== 'accept' }
  }
}
const forgedGraph = structuredClone(g0)
forgedGraph.nodes = forgedGraph.nodes.map(n => n.id === 'node:a' ? { ...n, label:'var(--forged)' } : n)
const forgedDigest = canonicalGraph(forgedGraph).digest
const forgedBinding = { ...b0, graph:{ ...b0.graph, graphDigest: forgedDigest } }
const forgedHost = { ...host, graphDigest: forgedDigest }
const badMappingGraph = structuredClone(g0)
badMappingGraph.sourceMappings[0].sourceUse = { ...badMappingGraph.sourceMappings[0].sourceUse, byteOffset:99 }
const unknownEnvelope = { ...b0, status:'unknown', primaryReasonCode:'observation/complete' }
const readsToJsxGraph = structuredClone(g0)
readsToJsxGraph.nodes.push({ id:'node:jsx', kind:'jsx-element', label:'<Button />' })
readsToJsxGraph.edges = readsToJsxGraph.edges.map(e => e.id === 'rel:a' ? { ...e, to:'node:jsx', kind:'reads', certainty:'source-proven', evidenceRefs:['jsx-control'] } : e)
const readsToJsxDigest = canonicalGraph(readsToJsxGraph).digest
const readsToJsxEnvelope = { ...b0, graph:{ ...b0.graph, graphDigest:readsToJsxDigest } }
const readsToJsxHost = { ...host, graphDigest:readsToJsxDigest }
const results = [
  observe('H0-01 caller-forged-host-binding-authentic-side', 'reject', 'executed', 'real graph + altered host graphDigest', () => validateGraphReference(b0, g0, { ...host, graphDigest:'2'.repeat(64) })),
  observe('H0-01b caller-forged-self-consistent-graph-and-binding', 'reject-by-production-registry', 'executed-boundary-gap', 'forged graph + caller-created matching binding', () => validateGraphReference(forgedBinding, forgedGraph, forgedHost)),
  observe('H0-02 caller-registers-or-overrides-host-binding', 'reject-by-production-registry', 'not-executable', 'registry mutation API absent from evidence helper', () => { throw Object.assign(new Error('no host registry API is present in evidence-only validator'), { code:'not-executable' }) }),
  observe('H0-03 cross-project-reuse-authentic-binding', 'reject', 'executed', 'envelope projectId differs from authentic host binding', () => validateGraphReference({ ...b0, graph:{ ...b0.graph, projectId:'project-other' } }, g0, host)),
  observe('H0-04 baseline-candidate-cross-side-reuse', 'reject', 'executed', 'candidate envelope passed to baseline host binding', () => validateGraphReference({ ...b0, side:'candidate' }, g0, host)),
  observe('H0-05 old-graphDigest-reused-for-new-graph', 'reject', 'executed', 'forged graph with old registered graphDigest', () => validateGraphReference({ ...b0, graph:{ ...b0.graph, graphDigest:graph0.digest } }, forgedGraph, host)),
  observe('H0-06 sourceDigest-does-not-match-host-snapshot-binding', 'reject', 'executed', 'envelope sourceDigest differs from host binding', () => validateGraphReference({ ...b0, graph:{ ...b0.graph, sourceDigest:'1'.repeat(64) } }, g0, host)),
  observe('H0-07 sourceMappings-do-not-match-selected-graph', 'reject', 'executed', 'mapping byteOffset changed against authentic host graph', () => validateGraphReference(b0, badMappingGraph, host)),
  observe('H0-08 runId-checkId-cross-session-valid-shape', 'reject-by-run-registry', 'executed-boundary-gap', 'valid but unregistered runId/checkId', () => validateGraphReference({ ...b0, runId:'run-B', checkId:'check-B' }, g0, host)),
  observe('H0-09 valid-route-page-viewport-replaced', 'reject-by-check-plan', 'executed-boundary-gap', 'valid alternate route/page/viewport tuple', () => validateGraphReference({ ...b0, route:'/other?x=2#other', page:{ pathname:'/other', search:'?x=2', hash:'#other' }, viewport:{ ...b0.viewport, width:412 } }, g0, host)),
  observe('H0-10 missing-host-binding-field', 'reject', 'executed', 'host binding graphDigest removed', () => { const missing = { ...host }; delete missing.graphDigest; return validateGraphReference(b0, g0, missing) }),
  observe('H0-11 unknown-must-not-upgrade-to-trusted', 'reject', 'executed', 'valid graph reference with status unknown', () => validateGraphReference(unknownEnvelope, g0, host)),
  observe('H0-12 historical-receipt-reused-in-new-run', 'reject-by-run-registry', 'executed-boundary-gap', 'old graph/artifact reused under new run/check', () => validateGraphReference({ ...b0, runId:'new-run', checkId:'new-check', artifact:{ ...b0.artifact, path:'runs/new-run/new-check/baseline.json' } }, g0, host)),
  observe('H0-13 static-reads-to-jsx-is-not-runtime-proof', 'accept-static-only', 'executed-control', 'reads + source-proven relation to jsx-element', () => validateGraphReference(readsToJsxEnvelope, readsToJsxGraph, readsToJsxHost)),
]
console.log(JSON.stringify({ protocol:'ripple-e-h0-adversarial-probe/v1', input:{ commit:'2ee08975c891abb1df5ff38881326e78ead28076', tree:'60e397f075f8a1d62226d6a736993580b48df9ad', validator:'docs/acceptance/2026-10-31/canonical-observation-digest.mjs' }, results }, null, 2))




