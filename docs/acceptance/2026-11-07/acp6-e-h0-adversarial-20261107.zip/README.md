# E-H0 P0 对抗证据包

日期：2026-11-07

## 精确输入

- V2 输入 commit：`2ee08975c891abb1df5ff38881326e78ead28076`
- V2 输入 tree：`60e397f075f8a1d62226d6a736993580b48df9ad`
- Runtime Identity v1.2 冻结 blob：`8bbecf6e3f64db2b68506eedaa8eea709d1167de`
- Validator：`docs/acceptance/2026-10-31/canonical-observation-digest.mjs`

## 文件清单

- `e-h0-adversarial-probe.mjs`：独立 adversarial probe 源码。
- `outputs/e-h0-adversarial-output.json`：五类缺口与 JSX 控制的原始输出。
- `inputs/`：G0、B0、host binding 和 mutation catalog。
- `outputs/frozen-*.stdout*`：冻结 Node、PowerShell、Schema、Dual 原始 stdout。
- `outputs/acp6-observation-v2-final-*.json`：冻结 Validator 生成报告。
- `environment/environment.json`：系统、版本、精确 SHA、退出码。
- `environment/frozen-command-results.json`：四个冻结命令的原始执行记录。
- `root-cause-call-chain.md`：缺口根因和调用链。
- `host-trust-wrapper-v1-design.md`：最小整改设计与白名单。
- `regression-plan.md`：整改后回归准入计划。
- `sha256-manifest.txt`：本证据包文件 SHA-256。

## 结果摘要

冻结 Validator 四项均退出 `0`：Node、PowerShell、Schema parity、Dual report；Dual report 为 `63/63` required negatives。

独立 probe 退出 `0`，但观察到以下真实接受行为：

1. caller 自洽伪造 Graph + binding 被 helper 返回 `trusted:true`；
2. 合法但未注册的 `runId/checkId` 被接受；
3. 合法但替换后的 route/page/viewport 被接受；
4. `status=unknown` 仍返回 `trusted:true`；
5. 历史 artifact 改挂到新 run/check 后仍被接受。

这些结果证明 helper 不能独立承担宿主信任根，也不能把 `trusted` 直接暴露给授权或 Runtime Identity 消费者。

`reads + source-proven → jsx-element` 控制也返回 `trusted:true`。该结果只能表示静态 Graph reference 通过，不能表示 JSX consumer 或运行时严格证明通过。

## 当前裁定

- Legacy V2 Offline：保留 PASS。
- E-H0 trust boundary：HOLD。
- E-H1 production host：HOLD。
- D-P1：HOLD。
- 本包没有修改 Runtime Identity v1.2、VerificationRun、Assessment、Scope、Candidate 或七项授权门控。
