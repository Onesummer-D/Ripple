# 缺口根因与精确调用链

## 1. `hostSideBinding` 的来源没有在 helper 内认证

文件：`docs/acceptance/2026-10-31/canonical-observation-digest.mjs`

- 332–353：`validateHostSideBinding()` 只校验字段闭集、格式、Graph canonical digest、project、side 和版本相等。
- 355–364：`validateGraphReference()` 接收调用者传入的 `hostSideBinding`，没有 registry lookup、不可伪造 handle 或宿主 provenance 检查。
- 因此“伪造 Graph + 伪造 matching binding”可通过。合同要求宿主 registry，但该 helper 只能在外层包装层被安全调用。

## 2. `trusted` 没有和 status 绑定

- 372–389：缺少 source reference 或 relation 时会降级。
- 390–397：只要 Graph reference、mapping 和 relation 通过，函数无条件返回 `trusted: true`，返回的 `status` 只是 `envelope.status ?? 'partial'`。
- 因此 `status=unknown`、旧 run、错误 page tuple 仍可产生 `trusted:true`。

## 3. run/check/page/viewport/state 没有与可信 check plan 比对

- 355–397 的函数签名只有 `(envelope, sideGraph, hostSideBinding)`。
- 没有 `runId/checkId` 期望值、trusted route、完整 page tuple、viewport、state 或 artifact lineage 参数。
- `canonicalObservationBinding()`（318–325）只重算 canonical digest；digest 是完整性摘要，不是宿主注册或执行证明。

## 4. 静态关系没有区分 JSX consumer/runtime proof

- 393–396 只检查 relation ID、`from`、sourceUse、`kind=reads`、`certainty=source-proven`。
- 没有要求 `to` 的消费者类型，也没有 runtime observation 或 Runtime Identity Assessment。
- `reads + source-proven → jsx-element` 因而能被 helper 接受。

## 5. 生产授权路径当前没有接入 V2 helper

精确 2ee 的 `src/` 和 `e2e/` 没有 `validateGraphReference()` 调用。

- `docs/acceptance/2026-11-07/d-e0-n01-n32/run-node.mjs:120–143` 是离线验收 harness，只输出诊断，不进入生产授权。
- `src/core/verification-receipt.ts:289–295` 仍使用既有 trusted Playwright executor / record hash 逻辑，未被 V2 `trusted` 改写。

因此当前危险是“未来误接线”风险，而不是已确认的生产授权绕过；整改必须在接线前完成。
