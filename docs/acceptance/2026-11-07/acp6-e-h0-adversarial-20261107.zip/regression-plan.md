# E-H0 下一次验收回归计划

所有用例必须在 Node、PowerShell、Schema parity、Dual report 中保持一致；宿主注册表用受控 test double 提供不可伪造的选定 side。

| ID | 输入 | 修复后断言 |
|---|---|---|
| H0-01 | caller 改 binding digest | `graph-digest-mismatch`，无 trusted |
| H0-01b | 自洽伪造 Graph + binding | registry 不匹配，`untrusted-capture` / unavailable |
| H0-02 | caller 写入/覆盖 binding | registry 拒绝，原 binding 不变 |
| H0-03 | projectId 借用 | `logical-project-mismatch` |
| H0-04 | baseline/candidate 互换 | `side-mismatch` |
| H0-05 | 新 Graph 使用旧 digest | `graph-digest-mismatch` |
| H0-06 | sourceDigest 与源码 bytes 不同 | `source-digest-mismatch` |
| H0-07 | mapping 与 Graph/anchor 不同 | `graph-schema-invalid` |
| H0-08 | 未注册 run/check | `cross-run` 或 `cross-check`，无 trusted |
| H0-09 | 合法但错误 route/page/viewport/state | `observation-tuple-mismatch` |
| H0-10 | missing/duplicate/conflict binding | unavailable/conflict，绝不选任一 binding |
| H0-11 | status unknown/partial/unavailable/stale | trusted 必须为 false |
| H0-12 | 旧 artifact 挂新 run/check | lineage mismatch / `cross-run` |
| H0-13 | reads→jsx-element 静态关系 | 只能 static evidence；runtimeProof 仍为 none |
| H0-14 | 缺失 artifact、错误 SHA、重复 archive | `artifact-missing` / `artifact-digest-mismatch` / conflict |
| H0-15 | 正式 RI Assessment 缺失或 reasons 非空 | RI strict pairing false，V2 不得升级 |

准入还需验证：

- 所有非 complete 状态的授权测试均断言 `trusted === false`；
- 恶意 caller 只能得到普通 envelope 解析错误，不能得到 host registry capability；
- 历史 candidate 回读包含相同 run/check/side/lineage；
- V2 结果不会出现在七项 Verification、Approval、Apply、Rollback 的输入字段中；
- Runtime Identity v1.2 blob、reason、recordKey、pairing 和正式 VerificationRun 回执 SHA 保持不变。

未完成以上回归前，E-H0 继续 HOLD。
